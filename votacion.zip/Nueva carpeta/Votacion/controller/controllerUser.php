<?php 
	require_once '../model/ClaseHabitante.php';
	require_once '../model/ClaseUsuario.php';
	sleep(1);
	if(isset($_POST['txtDui'])){
		loginVotante();
	}elseif(isset($_POST['txtUser'])&&isset($_POST['txtPass'])){
		loginAdmin();
	}

	/******* FUNCION LOGIN VOTANTE *********/
		function loginVotante()
		{
			$Dui = $_POST['txtDui'];
			$objHabitante = new ClaseHabitante();
			$datos=$objHabitante->loginVotante($Dui);
			echo $datos;
		}
	/***** FIN FUNCION LOGIN VOTANTE *******/

	/******* FUNCION LOGIN ADMINISTRADOR *********/
		function loginAdmin()
		{
			$user = $_POST['txtUser'];
			$pass = $_POST['txtPass'];
			$objUsuario = new  ClaseUsuario();
		    $data=$objUsuario->loginAdmin($user,$pass);
		    echo $data;
		}
	/***** FIN FUNCION LOGIN ADMINISTRADOR *******/
 ?>