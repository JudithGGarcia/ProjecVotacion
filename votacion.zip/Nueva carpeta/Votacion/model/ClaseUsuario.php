<?php 

	require_once 'Conexion.php';

	class ClaseUsuario extends Conexion 
	{
		private $usuario;
		private $contrasenia;
		private $rol;
		
		function __construct()
		{
			parent::__construct();
		}

	/********* METOS SET Y GET ***********/

		public function setUsuario($usuario)
		{
			$this->usuario=$usuario;
		}

		public function getUsuario()
		{
			return $this->usuario;
		}

		public function setContrasenia($contrasenia)
		{
			$this->contrasenia = $contrasenia;
		}

		public function getContrasenia()
		{
			return $this->contrasenia;
		}

		public function setRol($rol)
		{
			$this->rol = $rol;
		}

		public function getRol()
		{
			return $this->rol;
		}
	/******* FIN METOS SET Y GET *********/

	/********* FUNCION DE LOGEO DE USUARIOS *********/
		public function loginAdmin($user,$pass)
		{
			$cone = $this->Conexion();
			$sql = "SELECT 
						U.USUARIO ,
						R.NOMBRE AS ROL,
						U.NOMBRES as Nombre
						FROM USUARIO U INNER JOIN ROL R
						ON R.IDROL=U.IDROL
						WHERE PASS=".$pass." AND USUARIO='".$user."'";
			$datos = $cone->query($sql);
			if ($datos->num_rows>0) {
				$data = $datos->fetch_assoc();
				session_start();
				$_SESSION['NOMBRE']= $data['Nombre'];
			 	$_SESSION['ROL']= $data['ROL'];
			    $_SESSION['USER']= $data['USUARIO'];
				return json_encode(array('registro'=>true,$data['USUARIO'],$data['ROL']));
			}else{
			return json_encode(array('registro'=>false));	
			}
		}
	/******* FIN FUNCION DE LOGEO DE USUARIOS *******/

	/********* FUNCION DE MOSTRAR USUARIOS *********/
		public function mostrarUsuarios()
		{
			$cone = $this->Conexion();
			$sql ="SELECT  r.NOMBRE as rol,u.IDUSUARIO as id,u.PASS as pass, u.USUARIO as user, u.CODUSUARIO as codigo,u.NOMBRES as nombre, u.APELLIDOS as apellido FROM usuario u INNER JOIN rol r
					ON r.IDROL=u.IDROL WHERE u.ESTADO=1";
			$datos = $cone->query($sql);
			if ($datos->num_rows>0) {
				$data = $datos;
			}
			else{
				$data=false;
			}
        	
       		return $data;
		}
	/******* FIN FUNCION DE MOSTRAR USUARIOS *******/


}

 ?>



