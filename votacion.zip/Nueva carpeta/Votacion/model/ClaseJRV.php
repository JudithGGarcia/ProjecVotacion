<?php 
 
require_once "ClaseCentroVotacion.php";


class ClaseJRV extends ClaseCentroVotacion
{
	private $codigoJRV;
	private $correlativoJRV;
	
	public function __construct()
	{
		parent::__construct;
	}

	public function getCodigoJRV()
	{ 
		return $this->codigoJRV;
	}

	public function setCodigoJRV()
	{ 
		$this->codigoJRV=$codigoJRV;
	}

	public function getCorrelativoJRV()
	{ 
		return $this->correlativoJRV;
	}

	public function setCorrelativoJRV()
	{ 
		$this->correlativoJRV=$correlativoJRV;
	}

	public function Agregar()
	{ 
	}

	public function Modificar()
	{ 
	}

	public function Eliminar()
	{ 
	}

	public function Cancelar()
	{ 
	}
}

 ?>