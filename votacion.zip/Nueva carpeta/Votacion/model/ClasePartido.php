<?php 



class Partido
{
	private $nombrePartido;
	private $idPartido;
	private $foto;
	
	public function __construct()
	{
		
	}

	public function getNombrePartido()
	{ 
		return $this->nombrePartido;
	}

	public function setNombrePartido($nombrePartido)
	{ 
		$this->nombrePartido=$nombrePartido;
	}

	public function getidPartido()
	{ 
		return $this->idPartido;
	}

	public function setidPartido($idPartido)
	{ 
		$this->idPartido=$idPartido;
	}

	public function setFoto($foto)
	{
		$this->foto=$foto;
	}

	public function getFoto()
	{
		return $this->foto;
	}

	public function Agregar()
	{ 
	}

	public function Modificar()
	{ 
	}

	public function Eliminar()
	{ 
	}

	public function Cancelar()
	{ 
	}


}

 ?>