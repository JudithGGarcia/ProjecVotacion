<?php 

require_once "ClasePartido.php"


class ClaseCandidato extends ClasePartido
{
	private $nombreCandidato;
	private $duiCandidato;
	
	public function __construct()
	{
		parent::__construct;
	}

	public function getNombreCandidato()
	{ 
		return $this->nombre;
	}

	public function setNombreCandidato()
	{ 
		$this->nombreCandidato=$nombreCandidato;
	}

	public function getDuiCandidato()
	{ 
		return $this->duiCandidato;
	}

	public function setDuiCandidato()
	{ 
		$this->duiCandidato=$duiCandidato;
	}

	public function Agregar()
	{ 
	}

	public function Modificar()
	{ 
	}

	public function Eliminar()
	{ 
	}

	public function Cancelar()
	{ 
	}


}

 ?>