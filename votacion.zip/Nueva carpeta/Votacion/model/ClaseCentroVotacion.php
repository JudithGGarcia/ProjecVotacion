<?php 


class ClaseCentroVotacion 
{
	private $nombreCentroVotacion;
	private $codMunicipio;
	
	public function __construct()
	{
		
	}

	public function getCentroVotacion()
	{ 
		return $this->nombreCentroVotacion;
	}

	public function setCentroVotacion($nombreCentroVotacion)
	{ 
		$this->nombreCentroVotacion=$nombreCentroVotacion;
	}

	public function getCodMunicipio()
	{ 
		return $this->codMunicipio;
	}

	public function setCodMunicipio($codMunicipio)
	{ 
		$this->codMunicipio=$codMunicipio;
	}

	public function Agregar()
	{ 
	}

	public function Modificar()
	{ 
	}

	public function Eliminar()
	{ 
	}

	public function Cancelar()
	{ 
	}


}

 ?>