<?php 
	class Conexion 
	{
		private $host;
		private $user;
		private $password;
		private $database;


		function __construct()
		{
			$data = require_once '../app/confi.php';
			$this->host = $data['host'];
			$this->user = $data['user'];
			$this->password = $data['password'];
			$this->database = $data['database'];
		}


		public function Conexion()
		{
			$cone = new mysqli($this->host,$this->user,$this->password,$this->database);
			if ($cone->connect_errno) {
				echo "Tienes un error de conexion";
				die();
			}
			return $cone;
		}

	}

 ?>