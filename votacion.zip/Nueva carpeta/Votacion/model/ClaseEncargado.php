<?php 

require_once "ClaseCentroVotacion.php";


class ClaseEncargado extends ClaseCentroVotacion
{
	private $nombreEncargado;
	private $duiEncargado;
	
	public function __construct()
	{
		parent::__construct;
	}

	public function getNombreEncargado()
	{ 
		return $this->nombre;
	}

	public function setNombreEncargado($nombreEncargado)
	{ 
		$this->nombreEncargado=$nombreEncargado;
	}

	public function getDuiEncargado()
	{ 
		return $this->duiEncargado;
	}

	public function setDuiEncargado($duiEncargado)
	{ 
		$this->duiEncargado=$duiEncargado;
	}

	public function Agregar()
	{ 
	}

	public function Modificar()
	{ 
	}

	public function Eliminar()
	{ 
	}

	public function Cancelar()
	{ 
	}


}

 ?>