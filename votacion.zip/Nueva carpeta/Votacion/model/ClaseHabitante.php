<?php 
	require_once 'Conexion.php';

	class ClaseHabitante extends Conexion
	{
		private $nombre;
		private $dui;
		private $direccion;
		private $email;
		private $genero;
		private $foto;
		private $municipio;

		function __construct()
		{
			parent::__construct();
		}

		public function setNombre($nombre)
		{
			$this->nombre= $nombre;
		}

		public function getNombre()
		{
			return $this->nombre;
		}

		public function setDui($dui)
		{
			$this->dui=$dui;
		}

		public function getDui()
		{
			return $this->dui;
		}

		public function setDireccion($direccion)
		{
			$this->direccion= $direccion;
		}

		public function getDireccion()
		{
			return $this->direccion;
		}

		public function setEmail($email)
		{
			$this->email=$email;
		}

		public function getEmail()
		{
			return $this->email;
		}

		public function setGenero($genero)
		{
			$this->genero=$genero;
		}

		public function getGenero()
		{
			return $this->genero;
		}

		public function setFoto($foto)
		{
			$this->foto=$foto;
		}

		public function getFoto()
		{
			return $this->foto;
		}

		public function setMunicipio()
		{
			$this->municipio=$municipio;
		}

		public function getMunicipio()
		{
			return $this->municipio;
		}

		public function Agregar()
		{ 
		}

		public function Modificar()
		{ 
		}

		public function Eliminar()
		{ 
		}

		public function Cancelar()
		{ 
		}

		public function loginVotante($Dui)
		{
			$cone = $this->Conexion();
			$sql="SELECT NOMBRECOMPLETO as Nombre,VOTO AS Voto,GENERO AS Genero,DUI as Dui,DIRECCION AS Direccion,FOTO AS Foto FROM habitante WHERE ESTADO=1 AND Dui=".$Dui;
			$datos = $cone->query($sql);
			if ($datos->num_rows>0) {
				$data = $datos->fetch_assoc();
				session_start();
				$_SESSION['DUI']=$data['Dui'];
				return json_encode(array('registro'=>true,'Nombre'=>$data['Nombre'],'Genero'=>$data['Genero'],'Dui'=>$data['Dui'],'Direccion'=>$data['Direccion'],'Foto'=>$data['Foto'],'voto'=>$data['Voto']));

			}else{
				return json_encode(array('registro'=>false));
			}
		}
	}

 ?>