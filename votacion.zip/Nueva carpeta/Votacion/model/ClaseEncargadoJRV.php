<?php 

require_once "ClaseJRV.php"


class ClaseEncargadoJRV extends ClaseJRV
{
	private $dui;
	private $nombreEncargadoJRV;

	public function __construct()
	{
		parent::__construct;
	}

	public function getDUI()
	{ 
		return $this->dui;
	}

	public function setDUI()
	{ 
		$this->dui=$dui;
	}

	public function getNombreEncargadoJRV()
	{ 
		return $this->nombreEncargadoJRV;
	}

	public function setNombreEncargadoJRV()
	{ 
		$this->nombreEncargadoJRV=$nombreEncargadoJRV;
	}


	public function Agregar()
	{ 
	}

	public function Modificar()
	{ 
	}

	public function Eliminar()
	{ 
	}

	public function Cancelar()
	{ 
	}
}

 ?>