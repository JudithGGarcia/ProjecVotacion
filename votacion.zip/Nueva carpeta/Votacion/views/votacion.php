<!DOCTYPE html>
<html>
<head>
	<title>Votacion</title>
	<link rel="stylesheet" type="text/css" href="../vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/votacion.css">
	<script type="text/javascript" src="../vendor/jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../js/votacion.js"></script>
</head>
<body>
	<div class="col-md-12 container principal">
		<div class=" encabezado"><div class="col-md-9"><center>Bienvenido</center></div></div>
		<div class="contenedor"><br>
			<div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><br><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div><div class="contBanderas"></div>
		</div>
	</div>
</body>
</html>