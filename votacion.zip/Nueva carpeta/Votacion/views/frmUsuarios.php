<script type="text/javascript" src="js/usuario.js"></script>

  <!-- CUERPO DE LA PAGINA USUARIOS -->
  <div id="contenedorPrinc">
    <header style="font-size: 30px; color: white;">
      <div class="row">
        <div class="col-md-10"><center>Usuarios</center></div>
        </div>
        <div class="row">
          <div class="col-md-10" style="font-size: 15px;"><center>Gestión de usuarios</center></div><div class="col-md-2"><button class="btn btn-primary">Nuevo</button></div>
        </div>
    </header>
    <div class="col-md-12">
      <table cellspacing="1" id="registros" style="border-radius: 10px;margin-top: 40px; " class="mdl-data-table" width="100%">
          <thead>
            <th>Codigo</th>
            <th>Nombres</th>
            <th>Apellidos</th>
            <th>Username</th>
            <th>Password</th>
            <th>Tipo de usuario</th>
            <th>Acciones</th>
          </thead>
          <tbody id="cuerpo">
            <?php 
            require_once '../model/ClaseUsuario.php';
            $objUsuario = new ClaseUsuario();
            $dato = $objUsuario->mostrarUsuarios();          
              if ($dato) {
                foreach ($dato as $data) {
                  echo "  <tr>
                            <td>".$data['codigo']."</td>
                            <td>".$data['nombre']."</td>
                            <td>".$data['apellido']."</td>
                            <td>".$data['user']."</td>
                            <td>".$data['pass']."</td>
                            <td>".$data['rol']."</td>
                            <td>
                                <input type='button' class='btn-success btn-sm editarUsuario' id='".$data['id']."' value='Editar'>
                                 <input type='button' class='btn-danger btn-sm eliminarUsuario' id='".$data['id']."' value='Eliminar'>
                            </td>
                          </tr>
                ";
                }
              }else{
                echo "<tr><td colspan='7'>No hay usuarios que mostrar</td></tr>";
              }
             
          
             ?>
          </tbody>
      </table>
    </div><br><br>
  </div> 
  <!-- FIN CUERPO DE LA PAGINA USUARIOS -->

  <!-- MODAL DE INGRESO DE USUARIOS -->
  
  <!-- FIN MODAL DE INGRESO DE USUARIOS -->

