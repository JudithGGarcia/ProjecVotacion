<?php require_once 'app/validacionGeneral.php';?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>SB Admin - Start Bootstrap Template</title>
<?php require 'estructura/head.php'; ?>
</head>

<body class="fixed-nav sticky-footer bg-dark" >
  <?php require "estructura/menu.php";   ?>
  <div class="content-wrapper">
    <div class="container " id="contenido">
      
      
        



    </div>
  </div>

    <?php require 'estructura/messageLogou.php'; ?>
  <?php require 'estructura/footer.php'; ?>  
  
</body>

</html>
