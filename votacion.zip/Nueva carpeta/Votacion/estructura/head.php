  <meta charset="utf-8">
  
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

   <!-- Bootstrap core CSS-->
    <link rel="stylesheet" href="js/dataTable/material.min.css">
  <link rel="stylesheet" href="js/dataTable/dataTables.material.min.css"> 
  <link rel="stylesheet" href="js/sweetalert-master/dist/sweetalert.css">
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link rel="stylesheet" type="text/css" href="recursos/fonts.css">
  <link href="css/sb-admin.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="views/Pluggins/bootstrap/css/mio1.css">
  <link rel="stylesheet" type="text/css" href="css/styleMenu.css">
  <link rel="stylesheet" type="text/css" href="recursos/fonts.css">  

  <script type="text/javascript" src="js/jquery-3.3.1.js"></script>
  <script type="text/javascript" src="vendor/bootstrap/js/bootstrap.min.js"></script>  
  <script type="text/javascript" src="js/dataTable/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="js/dataTable/dataTables.material.min.js"></script>
  <script type="text/javascript" src="js/sweetalert-master/dist/sweetalert.min.js"></script>
  <script type="text/javascript" src="js/paginas.js"></script>
  <script type="text/javascript" src="js/usuario.js"></script>
 