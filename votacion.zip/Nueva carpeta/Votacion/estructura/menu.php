<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">

    <a class="navbar-brand" href="#"><?php    
    echo $_SESSION['NOMBRE'];
    echo '<input type="hidden" id="rolUsuario" value="'.$_SESSION['ROL'].'">';
     ?>      
    </a>
    
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarResponsive">

      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">

        <li id="usuarios" class="nav-item" data-toggle="tooltip" data-placement="right" title="Usuarios">
          <a class="nav-link" href="tables.html">
            <i class="icon-user"></i>
            <span class="nav-link-text">Usuarios</span>
          </a>
        </li>
        <li id="habitantes" class="nav-item" data-toggle="tooltip" data-placement="right" title="Habitantes">
          <a class="nav-link" href="tables.html">
            <i class="icon-man"></i>
            <span class="nav-link-text">Habitantes</span>
          </a>
        </li>

        <li id="Votacion" class="nav-item" data-toggle="tooltip" data-placement="right" title="Votacion">
          <a class="nav-link" href="index.html">
            <i class="icon-v-card"></i>
            <span class="nav-link-text">Votación</span>
          </a>
        </li>

        

        <li id="partidos" class="nav-item" data-toggle="tooltip" data-placement="right" title="Partidos Politicos">
          <a class="nav-link" href="charts.html">
            <i class="icon-sweden"></i>
            <span class="nav-link-text">Partidos politicos</span>
          </a>
        </li>
        <li id="JRV" class="nav-item" data-toggle="tooltip" data-placement="right" title="JRV">
          <a class="nav-link" href="tables.html">
            <i class="icon-shopping-bag"></i>
            <span class="nav-link-text">JRV</span>
          </a>
        </li>
        <li id="CV" class="nav-item" data-toggle="tooltip" data-placement="right" title="Centros de votacion">
          <a class="nav-link" href="tables.html">
            <i class="icon-shop"></i>
            <span class="nav-link-text">Centros de votacion</span>
          </a>
        </li>
        <li  id="grafica" class="nav-item" data-toggle="tooltip" data-placement="right" title="Grafica votaciones">
          <a class="nav-link" href="charts.html">
            <i class="icon-area-graph"></i>
            <span class="nav-link-text">Grafica de votaciones</span>
          </a>
        </li>
      </ul>
        <ul class="navbar-nav ml-auto">
        <li class="nav-item dropdown">
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Cerra sesion</a>
        </li>
      </ul>
   

      </div>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
    
  </nav>

