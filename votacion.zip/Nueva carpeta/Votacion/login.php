 <?php session_start();
    if (isset($_SESSION['DUI'])) {
        header("Location: index.php");
    }elseif (isset($_SESSION['ROL'])) {
        header("Location: index.php");
    } ?>

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Login</title>
        <script src="js/jquery-3.3.1.js"></script>
        <script src="js/validacion.js"></script>
        <script type="text/javascript" src="js/jQuery-Mask/src/jquery.mask.js"></script>
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/login.css">

    </head>
    <body>
        <div class="container">
        <div><center  class="alert alert-danger error"><span>Datos incorrectos, Intentelo de nuevo </span></center></div>  
        <div><center  class="alert alert-info errorVoto"><span>Estimado Votante: Se le informa que usted ya dio su sufragio, Muchas Gracias</span></center></div>  
            <div class="tab-content">
                <div id="Admin" class="tab-pane">
                    <form action="" id="frmAdmin" class="form-signin">
                        <p class="muted text-center">
                            Ingresa tu usuario y contraseña
                        </p>
                        <input type="text" placeholder="Usuario" name="txtUser" required class="input-block-level">
                        <input type="password" placeholder="Contraseña" name="txtPass" required class="input-block-level">
                        <input value="Ingresar" class="btn btn-large btn-primary btn-block" name="btnAdmin" id="btnAdmin" type="submit">
                    </form>
                </div>
                <div id="forgot" class="tab-pane active">
                    <form action="" id="frmVotante" class="form-signin">
                        <p class="muted text-center">
                           Ingresa tu numero de Dui
                        </p>
                        <input type="Text" id="mask" placeholder="03310699-3" name="txtDui" required="required" class="input-block-level" >
                        <br>
                        <br>
                        <input value="Ingresar" class="btn btn-large btn-primary btn-block" name="btnVotante" id="btnVotante" type="submit">
                    </form>
                </div>                
            </div>
            <div class="text-center">
                <ul class="inline">
                    <li><a class="muted" href="#Admin" data-toggle="tab">Administrador</a></li>
                    <li><a class="muted" href="#forgot" data-toggle="tab">Votante</a></li>
                </ul>
            </div>


        </div> <!-- /container -->    
        <script>window.jQuery || document.write('<script src="assets/js/vendor/jquery-1.10.1.min.js"><\/script>')</script>
        <script type="text/javascript" src="assets/js/vendor/bootstrap.min.js"></script>

        <script>
            $('.inline li > a').click(function() {
                var activeForm = $(this).attr('href') + ' > form';
                //console.log(activeForm);
                $(activeForm).addClass('magictime swap');
                //set timer to 1 seconds, after that, unload the magic animation
                setTimeout(function() {
                    $(activeForm).removeClass('magictime swap');
                }, 1000);
            });

        </script>   
    </body>
</html>
 