$(document).ready(function () {
	$('.error').hide();
	$('.errorVoto').hide();
	$('#mask').mask('00000000-0');
});

jQuery(document).on('submit','#frmVotante',function (event) {
	event.preventDefault();
	$('#btnVotante').val('Validando...');
	$.ajax({
		url: 'controller/controllerUser.php',
		type: 'POST',
		dataType: 'JSON',
		data:$(this).serialize(),
	})
	.done(function(res) {
		if(res.registro){
			if (res.voto==0)
			{
				location.href = "index.php";
				
			}else {
				$('.errorVoto').slideDown('slow');
				setTimeout(function () {
				$('.errorVoto').slideUp('slow');
				},2000);
				$('#btnVotante').val('Ingresar');

			}
		}else{
			$('.error').slideDown('slow');
			setTimeout(function () {
				$('.error').slideUp('slow');
			},2000);
			$('#btnVotante').val('Ingresar');
		}
	})
	.fail(function(error) {
		console.log(error);
	})
	.always(function() {
		console.log("complete");
	});
	

})

jQuery(document).on('submit','#frmAdmin',function (event) {
	event.preventDefault();
	$('#btnAdmin').val('Validando...');
	$.ajax({
		url: 'controller/controllerUser.php',
		type: 'POST',
		dataType: 'JSON',
		data:$(this).serialize(),
	})
	.done(function(res) {
		if(res.registro){
			location.href = "index.php";
		}else{
			$('.error').slideDown('slow');
			setTimeout(function () {
				$('.error').slideUp('slow');
			},2000);
			$('#btnAdmin').val('Ingresar');
		}
	})
	.fail(function(error) {
		console.log(error);
	})
	.always(function() {
		console.log("complete");
	});
	

})