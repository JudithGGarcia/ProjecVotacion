$(document).ready(function () {
	$('#contenido').load('views/frmUsuarios.php');
	validacionVisibilidad($('#rolUsuario').val());





/*********** METODO DE VALIDACION DE VISIBILIDAD ******************/
		function validacionVisibilidad(rol) {
			if(rol=='EJRV'){
				$('#partidos').hide();
				$('#usuarios').hide();
				$('#JRV').hide();
				$('#CV').hide();
			}else if(rol=='ECV'){
				$('#partidos').hide();
			}else if(rol=='EJRV'){
				$('#partidos').hide();
			}
		}
/*********** METODO DE VALIDACION DE VISIBILIDAD ******************/
});