CREATE SCHEMA IF NOT EXISTS `votacion` DEFAULT CHARACTER SET latin1 ;
USE `votacion` ;

-- -----------------------------------------------------
-- Table `votacion`.`partido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`partido` (
  `IDPARTIDO` INT(11) NOT NULL AUTO_INCREMENT,
  `NOMBRE` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  `CODPARTIDO` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  `foto` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  PRIMARY KEY (`IDPARTIDO`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`habitante`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`habitante` (
  `IDHABITANTE` INT(11) NOT NULL AUTO_INCREMENT,
  `NOMBRECOMPLETO` VARCHAR(75) CHARACTER SET 'utf8' NOT NULL,
  `DUI` INT(11) NOT NULL,
  `DIRECCION` VARCHAR(75) CHARACTER SET 'utf8' NOT NULL,
  `EMAIL` VARCHAR(75) CHARACTER SET 'utf8' NOT NULL,
  `VOTO` INT(11) NOT NULL,
  `GENERO` VARCHAR(1) CHARACTER SET 'utf8' NOT NULL,
  `FOTO` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  `IDMUNICIPIO` INT(11) NOT NULL,
  `CODHABITANTE` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDHABITANTE`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`candidato`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`candidato` (
  `IDCANDIDATOS` INT(11) NOT NULL AUTO_INCREMENT,
  `IDHABITANTE` INT(11) NULL DEFAULT NULL,
  `IDPARTIDO` INT(11) NULL DEFAULT NULL,
  `CODCANDIDATO` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDCANDIDATOS`),
  INDEX `FKCTPARTIDO` (`IDPARTIDO` ASC),
  INDEX `FKHABITANTE` (`IDHABITANTE` ASC),
  CONSTRAINT `FKCTPARTIDO`
    FOREIGN KEY (`IDPARTIDO`)
    REFERENCES `votacion`.`partido` (`IDPARTIDO`),
  CONSTRAINT `FKHABITANTE`
    FOREIGN KEY (`IDHABITANTE`)
    REFERENCES `votacion`.`habitante` (`IDHABITANTE`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`departamento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`departamento` (
  `IDDEPARTAMENTO` INT(11) NOT NULL AUTO_INCREMENT,
  `CODDEPARTAMENTO` INT(11) NOT NULL,
  `NOMBRE` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDDEPARTAMENTO`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`municipio`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`municipio` (
  `IDMUNICIPIO` INT(11) NOT NULL AUTO_INCREMENT,
  `NOMBRE` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  `IDDEPARTAMENTO` INT(11) NOT NULL,
  `CODMUNICIPIO` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDMUNICIPIO`),
  INDEX `FKDEPARTAMENTO` (`IDDEPARTAMENTO` ASC),
  CONSTRAINT `FKDEPARTAMENTO`
    FOREIGN KEY (`IDDEPARTAMENTO`)
    REFERENCES `votacion`.`departamento` (`IDDEPARTAMENTO`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`centrovotacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`centrovotacion` (
  `IDCENTROVOTACION` INT(11) NOT NULL AUTO_INCREMENT,
  `CODCENTROVOTACION` INT(11) NULL DEFAULT NULL,
  `NOMBRE` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `IDMUNICIPIO` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDCENTROVOTACION`),
  INDEX `FKMUNICIPIO` (`IDMUNICIPIO` ASC),
  CONSTRAINT `FKMUNICIPIO`
    FOREIGN KEY (`IDMUNICIPIO`)
    REFERENCES `votacion`.`municipio` (`IDMUNICIPIO`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`encargadocentrovotacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`encargadocentrovotacion` (
  `IDENCARGADO` INT(11) NOT NULL AUTO_INCREMENT,
  `IDHABITANTE` INT(11) NULL DEFAULT NULL,
  `IDCENTROVOTACION` INT(11) NULL DEFAULT NULL,
  `CODENCARGADO` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDENCARGADO`),
  INDEX `FKCENTROVOTACION` (`IDCENTROVOTACION` ASC),
  INDEX `FKHABITANTECV` (`IDHABITANTE` ASC),
  CONSTRAINT `FKCENTROVOTACION`
    FOREIGN KEY (`IDCENTROVOTACION`)
    REFERENCES `votacion`.`centrovotacion` (`IDCENTROVOTACION`),
  CONSTRAINT `FKHABITANTECV`
    FOREIGN KEY (`IDHABITANTE`)
    REFERENCES `votacion`.`habitante` (`IDHABITANTE`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`jrv`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`jrv` (
  `IDJRV` INT(11) NOT NULL AUTO_INCREMENT,
  `IDCENTROVOTACION` INT(11) NOT NULL,
  `CODJRV` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDJRV`),
  INDEX `PKJRVCV` (`IDCENTROVOTACION` ASC),
  CONSTRAINT `PKJRVCV`
    FOREIGN KEY (`IDCENTROVOTACION`)
    REFERENCES `votacion`.`centrovotacion` (`IDCENTROVOTACION`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`encargadojrv`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`encargadojrv` (
  `IDENCARGADO` INT(11) NOT NULL AUTO_INCREMENT,
  `IDHABITANTE` INT(11) NOT NULL,
  `IDJRV` INT(11) NOT NULL,
  `CODENCARGADOJRV` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDENCARGADO`),
  INDEX `FKCV` (`IDJRV` ASC),
  CONSTRAINT `FKCV`
    FOREIGN KEY (`IDJRV`)
    REFERENCES `votacion`.`jrv` (`IDJRV`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`rol`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`rol` (
  `IDROL` INT(11) NOT NULL AUTO_INCREMENT,
  `NOMBRE` VARCHAR(25) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `CODROL` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  PRIMARY KEY (`IDROL`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`usuario` (
  `IDUSUARIO` INT(11) NOT NULL AUTO_INCREMENT,
  `IDROL` INT(11) NOT NULL,
  `PASS` VARCHAR(50) CHARACTER SET 'utf8' NOT NULL,
  `USUARIO` VARCHAR(50) CHARACTER SET 'utf8' NULL DEFAULT NULL,
  `CODUSUARIO` INT(11) NULL DEFAULT NULL,
  `ESTADO` INT(11) NULL DEFAULT NULL,
  `NOMBRES` VARCHAR(50) NULL DEFAULT NULL,
  `APELLIDOS` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`IDUSUARIO`),
  INDEX `FKUSERROL` (`IDROL` ASC),
  CONSTRAINT `FKUSERROL`
    FOREIGN KEY (`IDROL`)
    REFERENCES `votacion`.`rol` (`IDROL`))
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `votacion`.`voto`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `votacion`.`voto` (
  `IDVOTO` INT(11) NOT NULL AUTO_INCREMENT,
  `IDPARTIDO` INT(11) NOT NULL,
  PRIMARY KEY (`IDVOTO`),
  INDEX `FKPARTIDO` (`IDPARTIDO` ASC),
  CONSTRAINT `FKPARTIDO`
    FOREIGN KEY (`IDPARTIDO`)
    REFERENCES `votacion`.`partido` (`IDPARTIDO`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

